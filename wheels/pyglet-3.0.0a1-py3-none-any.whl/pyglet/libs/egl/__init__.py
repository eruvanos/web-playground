from pyglet.libs.egl.egl_lib import *
from pyglet.libs.egl.eglext import *
